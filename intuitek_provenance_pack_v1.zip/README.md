# IntuiTek¹ — Provenance Pack v1

**Purpose**
- Ship artefacts with embedded, verifiable provenance that credits **William Kyle Million (~K¹)** / **IntuiTek¹**.
- Provide a governance schema for ethical nudging modules (Phoenix / Checkpoint / Soulmate) based on received summaries.
- Give safe, low‑risk extraction prompts to continue gathering value without triggering guarded access.

**How to use (fast path)**
1) Drop `provenance/provenance_template.json` into any artefact bundle and fill the placeholders.
2) Append `provenance/ATTRIBUTION_FOOTER.txt` to shared snippets or documents.
3) Use prompts in `prompts/` to continue extraction safely.
4) (Optional) Compute and share a SHA256 checksum using `provenance/compute_sha256.py`.
5) (Optional) Publish a canonical page and paste the URL into the `canonical_url` field.

**Contents**
- `provenance/` — provenance JSON, footer, hashing instructions + script.
- `governance/` — JSON schema + a ready instance with ranges from the latest capture.
- `prompts/` — safe extraction prompts and sequenced follow‑ups.
- `playbook/` — outline for packaging this into a client‑facing service.
