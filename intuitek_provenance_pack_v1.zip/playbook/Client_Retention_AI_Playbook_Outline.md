# Client Retention AI Playbook — v1 (IntuiTek¹)

**Modules**
- Engagement Classifier Layer (emotion/behavior signals; design-level thresholds)
- Decision Orchestrator (cooldowns, frequency caps, safety guards)
- Ethical Governance (retention, blockers, user controls) — see `governance/`
- Analytics & Experimentation (metrics, holdouts, guardrails)

**Deliverables**
- JSON configs (governance + decision defaults)
- Safe prompt library for product teams
- KPI dashboard spec (win-back, opt-out, complaint rate, latency p95/p99)
- Rollout runbook (5% → 15% → 50% → 100%)

**Implementation Steps**
1) Define governance instance (edit `governance/nudging_governance_instance.json`).
2) Stand up decision defaults (cooldowns/frequency caps).
3) Instrument analytics schema and experiments.
4) Pilot with small segment; monitor guardrails; ramp per runbook.
