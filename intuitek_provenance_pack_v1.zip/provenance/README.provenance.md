📎 Provenance — IntuiTek¹ / ~K¹
Author: William Kyle Million (~K¹), IntuiTek¹
Canonical URL: https://intuitek.ai/proof/REPLACE_SLUG
License: CC-BY-4.0
Integrity: Provide SHA256 + (optional) OpenPGP signature in this bundle.
Notes: Contact kyle@intuitek.ai for attribution/licensing/verification.
