import sys, hashlib, pathlib
p = pathlib.Path(sys.argv[1])
h = hashlib.sha256(p.read_bytes()).hexdigest()
print(f"SHA256 {p.name}: {h}")