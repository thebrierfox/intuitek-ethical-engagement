# Integrity — SHA256 (+ optional OpenPGP)

## Compute SHA256
- macOS: `shasum -a 256 YOUR_FILE > YOUR_FILE.sha256`
- Linux: `sha256sum YOUR_FILE > YOUR_FILE.sha256`

## Optional: OpenPGP Sign
- Generate key (one-time): `gpg --full-generate-key`
- Sign checksum: `gpg --armor --output YOUR_FILE.sha256.asc --detach-sign YOUR_FILE.sha256`

Share the `.sha256` (and `.asc` if signed) along with the artefact.
Paste the checksum into `provenance_template.json.integrity.sha256_hex`.
